# P-uppgift (Tic Tac Toe)
# Niclas Ericsson
# DD1314, Programmering för interaktiva medier, KTH

from tkinter import*
import random

#-------------------------------- Gameboard (Spelbrädet) ---------------------------------------------# 

class Gameboard():

#---------- Skapar en matris (ett Gameboard-objekt) ----------#

    def __init__(self, matrix):
        self.__matrix = matrix

#---------- Presentationsmetod för matrisen (UTGÅENDE) ----------#

    def __str__(self):
        return(str(self.__matrix))

#---------- Lägger till ett Symbol-objekt i matrisen/Gameboard-objektet ----------#

    def add_symbol_to_gameboard(self, symbol, column, row):
        print("Lägger ut din symbol..." + "\n")

#---------- Datorspelarens algoritmer ----------#
            
    def computer_player(self, symbol_X, symbol_O):
        print("Datorspelaren lägger ut sin markör...")      
                        
#---------- Ritar upp spelplanen i textformat ----------#

    def draw_gameboard(self):
        print("Ritar upp spelplanen...")

#---------- Kollar mellan varje drag om någon vunnit ----------#

    def win_check(self, symbol_X, symbol_O):
        print("Kollar ifall det är vinst på spelplanen...")

#---------- Kollar ifall alla spelfält på spelplanen är fulla ----------#

    def gameboard_full(self):
        print("Kollar ifall alla spelfält innehåller spelmarkörer...")

#---------- Sparar ner statistik i en textfil ----------#

    def save_statistics(self, win):
        print("Sparar statistik...")

#-------------------------------- Symbol (Spelmarkörerna) ---------------------------------------------------#

class Symbol():

#---------- Skapar Symbol-objekt (spelmarkörerna) ----------#
    
    def __init__(self, symbol):
        self.symbol = symbol

#---------- Presentationsmetod ----------#

    def __str__(self):
        return self.symbol

#-------------------------------- Main (därifrån programmet körs) --------------------------------------------#

class Main():

#---------- Skapar den grafiska huvudmenyn ----------#

    def main_menu(self):
        print("Laddar huvudmenyn..." + "\n")

#---------- Skapar en tom matris och returnerar den ----------#

    def create_matrix(self, infotext):
        print("Skapar en tom matris...")

#---------- Skapar Symbol-objekt och returnerar dem ----------#

    def create_symbol(self, symbol):
        print("Skapar symbol...")

#---------- Laddar in statistik ----------#
                
    def load_statistics(self):
        print("Laddar statistik...")

#---------- Visar upp statistiken i en ruta ----------#

    def show_statistics(self, wins_info, loses_info):
        print("Visar statistik...")
        
#---------- Start-metoden ----------#

    def main(self):
        print("Startar upp programmet...")


root = Tk()
root.title("Tic Tac Toe by Niclas Ericsson")

game = Main()
game.main()



# INFO, IDÉER OCH TIPS

# Start
# Meny med alternativ
    # Spela
        # => Spelplan ritas upp, spelet börjar
            # => Vid vinst => fråga spelaren om han/hon vill spela igen
    # Statistik => Lista med statistik läses in och ritas upp
    # Avsluta

# Skilj på logik och grafik!
