Tic Tac Toe v1.75
Niclas Ericsson
DD1314 Programming for Interactive Media, KTH

---------------------------------------------

To run this Python script you need to have Python 3.3 or higher installed on your computer.

The Tic Tac Toe/Images folder must contain the following files in order to run Tic Tac Toe.py:

empty_field.gif
main_menu_pic.gif
standard_O.gif
standard_X.gif
01_luigi.gif
01_mario.gif
02_megaman.gif
02_drwily.gif
03_metalslugcar.gif
03_metalslugsoldier.gif

If not, a message will appear with the text "Bildfilerna kunde inte hittas".

Also, make sure that the file "statistics.txt" is in the folder as well. If not, the game will go bananas.

All of these files are included in the Tic Tac Toe zip-file.